﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Dapper;

namespace NorthWindTest.Models
{
    public class Category
    {
        public int CategoryID { get; set; }

        public string CategoryName { get; set; }

        public string Description { get; set; }

        public string Picture { get; set; }


        // public List<Product> Products { get; set; }




        public async Task<int> Insert()
        {
            try
            {
                using (var con = DBUtility.GetNewOpenConnection())
                {
                    var p = new DynamicParameters();
                    p.Add("@CategoryName", this.CategoryName);
                    p.Add("@Description", this.Description);
                   // p.Add("@Picture", this.Picture);                
                    
                    this.CategoryID = await con.ExecuteScalarAsync<int>(sql: "dbo.usp_Category_Insert", param: p, commandType: CommandType.StoredProcedure);
                    return this.CategoryID;

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
            }
        }







        public static IEnumerable<SelectListItem> GetCategorySelectListItmes()
        {
            IEnumerable<Category> categoryList;
            using (var con = DBUtility.GetNewOpenConnection())
            {
                categoryList = con.Query<Category>(sql: "dbo.usp_Category_GetCategorySelectListItmes", commandType: CommandType.StoredProcedure);
            }
            return categoryList.OrderBy(x => x.CategoryName).Select(x => new SelectListItem { Value = x.CategoryID.ToString(), Text = x.CategoryName });
        }
    }
}