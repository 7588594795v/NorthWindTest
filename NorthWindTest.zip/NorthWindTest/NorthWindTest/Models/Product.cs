﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace NorthWindTest.Models
{
    public class ProductCreateViewModel
    {
        public Product Product { get; set; }
        public Category Category { get; set; }
    }

    public class Product
    {
        public int ProductID { get; set; }

        public string ProductName { get; set; }

   
        public int? SupplierID { get; set; }

        public int? CategoryID { get; set; }

        public string QuantityPerUnit { get; set; }

        public decimal? UnitPrice { get; set; }

        public Int16? UnitsInStock { get; set; }

        public Int16? UnitsOnOrder { get; set; }

        public Int16? ReorderLevel { get; set; }

        public bool Discontinued { get; set; }


        public string CategoryName { get; set; }

        public enm_CategoryType CategoryType { get; set; }




        public async Task<int> Insert()
        {
            try
            {
                using (var con = DBUtility.GetNewOpenConnection())
                {
                    var p = new DynamicParameters();
                    p.Add("@ProductName", this.ProductName);
                    p.Add("@SupplierID", this.SupplierID);
                    p.Add("@CategoryID", this.CategoryID);
                    p.Add("@QuantityPerUnit", this.QuantityPerUnit);
                    p.Add("@UnitPrice", this.UnitPrice);
                    p.Add("@UnitsInStock", this.UnitsInStock);
                    p.Add("@UnitsOnOrder", this.UnitsOnOrder);
                    p.Add("@ReorderLevel", this.ReorderLevel);
                    p.Add("@Discontinued", this.Discontinued);
                    this.ProductID = await con.ExecuteScalarAsync<int>(sql: "dbo.usp_Product_Insert", param: p, commandType: CommandType.StoredProcedure);
                    return this.ProductID;

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
            }
        }


        public async Task Update()
        {
            try
            {
                using (var con = DBUtility.GetNewOpenConnection())
                {
                    var p = new DynamicParameters();
                    p.Add("@ProductID", this.ProductID);
                    p.Add("@ProductName", this.ProductName);
                    p.Add("@SupplierID", this.SupplierID);
                    p.Add("@CategoryID", this.CategoryID);
                    p.Add("@QuantityPerUnit", this.QuantityPerUnit);
                    p.Add("@UnitPrice", this.UnitPrice);
                    p.Add("@UnitsInStock", this.UnitsInStock);
                    p.Add("@UnitsOnOrder", this.UnitsOnOrder);
                    p.Add("@ReorderLevel", this.ReorderLevel);
                    p.Add("@Discontinued", this.Discontinued);
                    await con.ExecuteAsync(sql: "dbo.usp_Product_Update", param: p, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
            }
        }

        public async Task Delete(int productID)
        {
            try
            {
                using (var con = DBUtility.GetNewOpenConnection())
                {
                    var p = new DynamicParameters();
                    p.Add("@ProductID", productID);                   
                    await con.ExecuteAsync(sql: "dbo.usp_Product_Delete", param: p, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
            }
        }

        public async Task<Product> GetByPrimaryKey(int id)
        {
            using (var con = DBUtility.GetNewConnection())
            {
                var p = new DynamicParameters();
                p.Add("@ProductID", id);
                var result = await con.QueryAsync<Product>(sql: "dbo.usp_Product_GetByPrimaryKey", param: p, commandType: CommandType.StoredProcedure);
                return result.FirstOrDefault();
            }
    
        }

        public static async Task<IEnumerable<Product>> List()
        {
            IEnumerable<Product> productList;
            using (var con = DBUtility.GetNewOpenConnection())
            {
                productList = await con.QueryAsync<Product>(sql: "dbo.usp_Product_Index", commandType: CommandType.StoredProcedure);
                return productList;
            }
        }

        public enum enm_CategoryType
        {
            New=1,
            Existing=2
        }

    }

}