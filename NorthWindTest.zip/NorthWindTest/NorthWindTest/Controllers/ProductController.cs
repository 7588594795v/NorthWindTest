﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

using NorthWindTest.Models;
using static NorthWindTest.Models.Product;
using System.Activities.Statements;

namespace NorthWindTest.Controllers
{
    public class ProductController : Controller
    {

        // GET: Product
        [HttpGet]
        [Authorize]
        public async Task<ActionResult> List()
        {
            var model = await Product.List();
            return View(model);
        }

        [HttpGet]
        [Authorize]
        public ActionResult Add()
        {
            var model = new ProductCreateViewModel { Product = new Product(), Category = new Category() };
            return View(model);
        }


        [HttpPost]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Add(ProductCreateViewModel productCreateViewModel)
        {
            if (ModelState.IsValid)
            {

                try
                {
                    if (productCreateViewModel.Product.CategoryType == enm_CategoryType.New)
                    {
                        productCreateViewModel.Product.CategoryID = await productCreateViewModel.Category.Insert();

                    }

                    int id = await productCreateViewModel.Product.Insert();

                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return RedirectToAction("List", "Product");
        }


        [HttpGet]
        [Authorize]
        public async Task<ActionResult> Edit(int id)
        {
            var product = new Product();
            var _product = await product.GetByPrimaryKey(id);
            return View(new ProductCreateViewModel { Product = _product });
        }

        [HttpPost]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(ProductCreateViewModel productCreateViewModel)
        {
            if (ModelState.IsValid)
            {
                if (productCreateViewModel.Product.CategoryType == enm_CategoryType.New)
                {
                    productCreateViewModel.Product.CategoryID = await productCreateViewModel.Category.Insert();
                }

                await productCreateViewModel.Product.Update();

            }
            return RedirectToAction("List", "Product");
        }

        [HttpPost]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Delete(Product model)
        {
            try
            {
                var product = new Product();
                await product.Delete(model.ProductID);
                return RedirectToAction("List", "Product");
            }

            catch
            {
                return RedirectToAction("List", "Product");
            }

        }


    }
}